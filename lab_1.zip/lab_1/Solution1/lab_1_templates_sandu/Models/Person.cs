﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace lab_1_templates_sandu.Models
{
	public class Person
	{
        public string specialitatea { get; set; }
        public int grupa { get; set; }

        public string name { get; set; }
    }
}